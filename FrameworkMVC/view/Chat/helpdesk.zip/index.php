<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>HelpDesk</title>

<?php include("links.php"); ?>

</head>
<body>
<table border="0" cellpadding="1" cellspacing="0" id="contenido" style="width:100%; height:100%; margin-left:-1px; margin-top: -1px;">
  <tr>
    <td valign="middle" class="title">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="middle"><table cellpadding="2" cellspacing="2" id="login" style="width:250px;height:120px;"">
      <tr>
        <td align="center" valign="middle"><p><a class="link" href="javascript:abrir('login.php',0,0,0,0,0,0,0,820,620,0,0,0);">Iniciar sesi&oacute;n</a><br />
          <a class="link" href="javascript:abrir('register.php',0,0,0,0,0,0,0,820,620,0,0,0);">Registrarse</a></td>
      </tr>
      </table>
    <br /></td>
  </tr>
</table>
</body>
</html>
