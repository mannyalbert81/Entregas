<!-- Icon files -->
<link rel="shortcut icon" href="ico/favicon.ico"/>
<link rel="icon" href="ico/favicon.ico"/> 

<!-- Estilos css -->
<!-- <link rel="stylesheet" href="css/helpdesk.rosa.css" type="text/css" /> -->
<!-- <link rel="stylesheet" href="css/helpdesk.nara.css" type="text/css" /> -->
<!-- <link rel="stylesheet" href="css/helpdesk.azul.css" type="text/css" /> -->
<!-- <link rel="stylesheet" href="css/helpdesk.verd.css" type="text/css" /> -->
<link rel="stylesheet" href="css/helpdesk.azul.css" type="text/css" />
<link rel="stylesheet" href="css/tootip.css" type="text/css">

<!-- Funciones -->
<script type="text/javascript" src="js/helpdesk.js"></script>