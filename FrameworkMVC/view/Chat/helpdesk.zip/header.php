<?php
	include('config/constants.php');
	include('config/functions.php');
	include('config/class.php');	
	include('config/objects.php');
?>